package Pages;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class logSetup {
	
	Logger logger ;

	public Logger log() {
		logger = LogManager.getLogger(logSetup.class);
		return logger;
		
	}
	
}
