package Pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

public class RiderInfoPage {
	
	WebDriver driver;
	logSetup log;
	public RiderInfoPage(WebDriver driver)
	{	
		PageFactory.initElements(driver, this);
		this.driver = driver;
		log = new logSetup();
	}
	@FindBy(how=How.XPATH,using=".//input[@id='NextBusSearchTerm']")
	WebElement searchBus;
	
	@FindBy(how=How.XPATH,using=".//button[@type='submit' and @form='NextBusSearch']")
	WebElement findMyNextBusBtn;
	
	@FindBy(how=How.XPATH,using=".//a[@href='/next-bus/favourites']")
	WebElement myFavBtn;
	
	
	
	
	public void searchNextBus() {
		searchBus.sendKeys("99");
		log.log().info("Enter 99 in the BusRoute field");
		findMyNextBusBtn.click();
		log.log().info("Clicked on FindMyNextBus icon");
		
	}
	
	public void gotoMyfavBtn() {
		
		myFavBtn.click();
		log.log().info("Clicked on My Favourite button");
	}
}
