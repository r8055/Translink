package Pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

public class myFavRoute {

	WebDriver driver;
	logSetup log;
	public myFavRoute(WebDriver driver)
	{	
		PageFactory.initElements(driver, this);
		this.driver = driver;
		log = new logSetup();
	}
	
	@FindBy(how=How.XPATH,using=".//div[@id='MainContent_PanelStops']/div[1]")
	WebElement myRouteText;
	
	@FindBy(how=How.XPATH,using=".//div//a[@href='/text/route/099/direction/EAST']")
	WebElement  myBus;
	
	@FindBy(how=How.XPATH,using=".//iframe[@title='Next Bus']")
	WebElement  myFrame;
	
	@FindBy(how=How.XPATH,using=".//a[text()='UBC Exchange Bay 7']")
	WebElement  bay07;
	
	@FindBy(how=How.XPATH,using=".//div[text()='Stop # 61935']")
	WebElement  myStopId;
	
	
	
	
	
	
	public boolean validateMyRouteAndSelectMyBus() throws InterruptedException {
		driver.switchTo().frame(myFrame);
		boolean route = myRouteText.isDisplayed();
		log.log().info("My Route text is displayed");
		myBus.click();
		log.log().info("Clicked on my bus");
		Thread.sleep(3000);
		driver.switchTo().defaultContent();
		return route;
	}
	
	public void selectMyBay() throws InterruptedException {
		Thread.sleep(2000);
		driver.switchTo().frame(myFrame);
		bay07.click();
		log.log().info("clicked on Bay7");
		Thread.sleep(3000);
		driver.switchTo().defaultContent();
		
	}
	
	public boolean validateStopId() throws InterruptedException {
		Thread.sleep(2000);
		driver.switchTo().frame(myFrame);
		boolean value = myStopId.isDisplayed();
		log.log().info("StopID is displayed");
		Thread.sleep(3000);
		driver.switchTo().defaultContent();
		return value;
		
	}
	
}


