package Pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

public class favouriteRoute extends logSetup {

	WebDriver driver;
	logSetup log;
	public favouriteRoute(WebDriver driver)
	{	
		PageFactory.initElements(driver, this);
		this.driver = driver;
		log = new logSetup();
	}
	
	@FindBy(how=How.XPATH,using=".//button[contains(@class,'AddDelFav')]")
	WebElement favBtn;
	
	@FindBy(how=How.XPATH,using=".//section//div[contains(@class,'flexContainer')]/button[text()='Add to Favourites']")
	WebElement addToFavBtn;
	
	@FindBy(how=How.XPATH,using=".//textarea[@name='newFavourite' and @aria-invalid='false']")
	WebElement name;
	
	@FindBy(how=How.XPATH,using=".//a[@class=' verticallyCenteredItem']")
	WebElement myRouteLink;
	
	
	
	
	
	public void addFavItem() {
		favBtn.click();
		log.log().info("Clicked on Add Favourite button");
		name.sendKeys("Translink Auto Homework");
		log.log().info("Saving as Translink Auto Homework ");
		addToFavBtn.click();
		log.log().info("Clicked on Add to favourite button ");

		
	}
	
	public boolean validateMyRouteLink() {
		boolean value = myRouteLink.isDisplayed();
		log.log().info("My route link is displayed ");
		return value;
	}
	
	public void gotoMyRouteLink() {
		myRouteLink.click();
		log.log().info("Clicked on my route link ");
	}
	
	
	
}
