package Testcases;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Test;

public class testBase {

	WebDriver driver;
	@BeforeSuite
	public void startSession() throws Exception
	{
		System.setProperty("webdriver.chrome.driver", "chromedriver.exe");
		driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		driver.get("https://translink.ca");
		Thread.sleep(2000);	
	}
	public WebDriver getDriver()
	{
		return this.driver;
	}

	@AfterSuite 

	public void close() 
	{ if(driver != null) 
	{ 
		driver.quit(); 
		driver= null; 

	} 
	else 
		System.out.println("Driver is already dead"); }


}



