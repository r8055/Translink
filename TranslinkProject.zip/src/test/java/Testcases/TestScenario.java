package Testcases;

import org.testng.Assert;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import Pages.LandingPage;
import Pages.RiderInfoPage;
import Pages.favouriteRoute;
import Pages.myFavRoute;


public class TestScenario extends testBase {
	LandingPage Lpage;
	RiderInfoPage Rpage;
	favouriteRoute Fpage;
	myFavRoute FavPage;
	testBase testbase;
	@BeforeTest
	public void begin()
	{
		testbase= new testBase();
		Lpage= new LandingPage(getDriver());
		Rpage= new RiderInfoPage(getDriver());
		Fpage= new favouriteRoute(getDriver());
		FavPage= new myFavRoute(getDriver());
	}
	
	@Test
	public void getavailableBus() throws InterruptedException {
		Thread.sleep(2000);	
		Lpage.clickOnNextBus();	
		Rpage.searchNextBus();
		Fpage.addFavItem();
		Rpage.gotoMyfavBtn();
		boolean value = Fpage.validateMyRouteLink();
		Assert.assertTrue(value,"My favorite Link is not present");
		Fpage.gotoMyRouteLink();
		
		boolean textValue = FavPage.validateMyRouteAndSelectMyBus();
		Assert.assertTrue(textValue,"My favorite route is not present");	
		
		FavPage.selectMyBay();
		
		boolean stopIdValue = FavPage.validateStopId();
		Assert.assertTrue(stopIdValue,"My stopID is not present");	
		
	
	}
	
	

}
